<?php
    // configuration
    require("../includes/config.php");
    
    $str = "select PS.*, Pr.name as producer, PT.type_name, P.*, U.username, 
                        M.name as metal, M.probe
                        from Product as P inner join Producer as Pr on Pr.id = P.producer_id
                        inner join Product_type as PT on PT.id = P.type_id
                        inner join Presence as Ps on Ps.id = P.presence_id
                        inner join users as U on U.id = P.user_id
                        inner join Product_sold as PS on P.id = PS.product_id
                        inner join Metal as M on M.id = P.metal_id";
    
    if ($_SERVER['REQUEST_METHOD'] == 'POST') {
        if (isset($_POST['search'])) {
        
        //function that checks
        function IsChecked($chkname,$value)
        {
        if(!empty($_POST[$chkname]))
        {
            foreach($_POST[$chkname] as $chkval)
            {
                if($chkval == $value)
                {
                    return true;
                }
            }
        }
        return false;
        }

        if(empty($_POST['formDoor']))
        {
            //echo("Вы ничего не выбрали.");
        }
        else
        {
            $a_s=$_POST['start_date'];
            $a_e=$_POST['end_date'];
            $b=$_POST['producer'];
            $c=$_POST['type'];
            $d=$_POST['manager'];
            
            $A="";$B="";$C="";$D="";$And="";
            
            if(IsChecked('formDoor','A'))
            {
                $A=" PS.data BETWEEN STR_TO_DATE('$a_s', '%Y-%m-%d') AND STR_TO_DATE('$a_e', '%Y-%m-%d')";
                $And=" AND";
            }
            if(IsChecked('formDoor','B'))
            {
                $B=$And . " Pr.name = '$b'";
                $And=" AND";
            }
            if(IsChecked('formDoor','C'))
            {
                $C=$And . " PT.type_name = '$c'";
                $And=" AND";
            }
            if(IsChecked('formDoor','D'))
            {
                $D=$And . " U.username = '$d'";
            }
            
            $str=$str . " where" . $A . $B . $C . $D;
        }

       }
    }
    
    // query user's portfolio
   $rows =	CS50::query($str);	
	// create new array to store all info for portfolio table
	$portfolio = [];
	
	$q_t=0; $p_t=0; $ps_t=0;$profit=0;
	// for each of products
	foreach ($rows as $row)	
    {   
        $product["id"] = $row["id"];
        
        $product["producer"] = $row["producer"];
        if ($product["producer"] == "Gloria")
        {
            $product["producer"] = "Глория";
        }
        else if ($product["producer"] == "Rubin")
        {
            $product["producer"] = "Рубин";
        }

        $product["type"] = $row["type_name"];
        if ($product["type"] == "Ring")
        {
            $product["type"] = "Кольцо";
        }
        else if ($product["type"] == "Earrings")
        {
            $product["type"] = "Серьги";
        }
        else if ($product["type"] == "Pendant")
        {
            $product["type"] = "Подвес";
        }
        else if ($product["type"] == "Chain")
        {
            $product["type"] = "Цепочка";
        }
        
       // $product["presence"] = $row["presence"];

        $product["user"] = $row["username"];
        
       // $product["gender"] = $row["gender"];

        $product["metal"] = $row["metal"];
        if ($product["metal"] == "Silver")
        {
            $product["metal"] = "Серебро";
        }
        
        $product["probe"] = $row["probe"];
        
        $product["price"] = $row["price"];

        $product["articul"] = $row["articul"];
        
        $product["size"] = $row["size"];
        /*if ($product["size"] == "NULL")
        {
            $product["size"] = "";
        }*/

        $product["size_common"] = $row["size_common"];
        
        $product["weight"] = $row["weight"];

        $product["quantity"] = $row["quantity"];
        
        $product["gem_quantity"] = $row["gem_quantity"];
        $product["data"] = $row["data"];
        $product["price_s"] = $row["price_s"];
        $product["quantity_s"] = $row["quantity_s"];
        
        $q_t = $q_t + $row["quantity_s"];
        $p_t = $p_t + $row["price"]*$row["quantity_s"];
        $ps_t = $ps_t + $row["price_s"]*$row["quantity_s"];
        $profit = $profit + ($row["price_s"]*$row["quantity_s"] - $row["price"]*$row["quantity_s"]);

        // save the row in the new array
        $portfolio[] = $product;
    }
    
    if ($_SERVER['REQUEST_METHOD'] == 'POST') {

    if (isset($_POST['cancel'])) {

        $rowToDelete = intval($_POST['cancel']);

        CS50::query("UPDATE Product SET presence_id = 1 WHERE id = ?", $rowToDelete); 
        redirect("/"); 

    }
    if (isset($_POST['reserve'])) {

        $rowToDelete = intval($_POST['reserve']);

        CS50::query("UPDATE Product SET presence_id = 2 WHERE id = ?", $rowToDelete); 
        redirect("/reserved.php"); 
    }
    if (isset($_POST['ex'])) {
    
        function cleanData(&$str)
      {
        $str = preg_replace("/\t/", "\\t", $str);
        $str = preg_replace("/\r?\n/", "\\n", $str);
        if(strstr($str, '"')) $str = '"' . str_replace('"', '""', $str) . '"';
      }
    
      // filename for download
      $filename = "Report_" . date('Ymd') . ".xls";
    
      header("Content-Disposition: attachment; filename=\"$filename\"");
      header("Content-Type: application/vnd.ms-excel");
    
      $flag = false;
      foreach($portfolio as $row) {
        if(!$flag) {
          // display field/column names as first row
          echo implode("\t", array_keys($row)) . "\r\n";
          $flag = true;
        }
        
        array_walk($row, __NAMESPACE__ . '\cleanData');
        echo implode("\t", array_values($row)) . "\r\n";
      }
      exit;
    }

    
}

    // query producer
        $rows =	CS50::query("SELECT name as producer FROM Producer");	
        // create new array 
        $producers = [];
        // for each of producers
        foreach ($rows as $row)	
        {   
            // save 
            $producer = $row["producer"];
            
            // add to the new array
            $producers[] = $producer;       
        }
        
        // query type
        $rows =	CS50::query("SELECT type_name FROM Product_type");	
        // create new array 
        $types = [];
        // for each of types
        foreach ($rows as $row)	
        {   
            // save 
            $type = $row["type_name"];
            
            // add to the new array
            $types[] = $type;       
        }
        // query manager
        $rows =	CS50::query("SELECT username FROM users");	
        // create new array
        $managers = [];
        // for each of managers
        foreach ($rows as $row)	
        {   
            // save 
            $manager = $row["username"];
            
            // add to the new array
            $managers[] = $manager;       
        }

    // query user for login
    $users = CS50::query("SELECT * FROM users WHERE id = ?", $_SESSION["id"]);
    // render portfolio
    render("sold_form.php", ["title" => "Продано", "portfolio" => $portfolio, "users" => $users, "producers" => $producers, "types" => $types, "managers" => $managers,
    "q_t" => $q_t, "p_t" => $p_t, "ps_t" => $ps_t, "profit" => $profit]);
?>