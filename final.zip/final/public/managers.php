<?php
    // configuration
    require("../includes/config.php");
    
    // count user's sold product
    $rows =	CS50::query("Select U.username as user,
    (SELECT SUM( PS.quantity_s ) FROM Product_sold AS PS, Product AS P
    WHERE P.type_id=1 AND PS.user_id = U.id AND P.id = PS.product_id) as QRing,
    (Select SUM(PS.quantity_s) FROM Product_sold as PS, Product as P
    WHERE P.type_id=2 AND PS.user_id = U.id AND P.id = PS.product_id) as QEarrings,
    (Select SUM(PS.quantity_s) FROM Product_sold as PS, Product as P
    WHERE P.type_id=3 AND PS.user_id = U.id AND P.id = PS.product_id) as QPendant,
    (Select SUM(PS.quantity_s) FROM Product_sold as PS, Product as P 
    WHERE P.type_id=4 AND PS.user_id = U.id AND P.id = PS.product_id) as QChain From users U");	
	
	$All_ring = 0; $All_earrings = 0; $All_pendant = 0; $All_chanes = 0; $All = 0;
	
	// create new array to store all info for portfolio table
	$products_per_user = [];
	// for each of user's products
	foreach ($rows as $row)	
    {   
        // add user to the row
        $product_per_user["user"] = $row["user"];
        
        // add QRing to the row
        $product_per_user["QRing"] = $row["QRing"];
        
        // add QEarrings to the row
        $product_per_user["QEarrings"] = $row["QEarrings"];
        
        // add QPendant to the row
        $product_per_user["QPendant"] = $row["QPendant"];
        
        // add QChain to the row
        $product_per_user["QChain"] = $row["QChain"];
        
        // add total price to the row
        $product_per_user["total"] = $product_per_user["QRing"] + $product_per_user["QEarrings"] + $product_per_user["QPendant"] + $product_per_user["QChain"];
        
        // save the row in the new array
        $products_per_user[] = $product_per_user;
        
        $All_ring = $All_ring + $product_per_user["QRing"];
        $All_earrings = $All_earrings + $product_per_user["QEarrings"];
        $All_pendant = $All_pendant + $product_per_user["QPendant"];
        $All_chanes = $All_chanes + $product_per_user["QChain"];
        $All = $All + $product_per_user["total"];
        
    }
    
    // count user's available product
    $rows1 =	CS50::query("Select U.username as user,
    (Select SUM(quantity) FROM Product WHERE type_id=1 AND presence_id=1 AND user_id = U.id) as QRing,
    (Select SUM(quantity) FROM Product WHERE type_id=2 AND presence_id=1 AND user_id = U.id) as QEarrings,
    (Select SUM(quantity) FROM Product WHERE type_id=3 AND presence_id=1 AND user_id = U.id) as QPendant,
    (Select SUM(quantity) FROM Product WHERE type_id=4 AND presence_id=1 AND user_id = U.id) as QChain From users U");	
	
	$All_ring1 = 0; $All_earrings1 = 0; $All_pendant1 = 0; $All_chanes1 = 0; $All1 = 0;
	
	// create new array to store all info for portfolio table
	$products_per_user1 = [];
	// for each of user's products
	foreach ($rows1 as $row)	
    {   
        // add user to the row
        $product_per_user["user"] = $row["user"];
        
        // add QRing to the row
        $product_per_user["QRing"] = $row["QRing"];
        
        // add QEarrings to the row
        $product_per_user["QEarrings"] = $row["QEarrings"];
        
        // add QPendant to the row
        $product_per_user["QPendant"] = $row["QPendant"];
        
        // add QChain to the row
        $product_per_user["QChain"] = $row["QChain"];
        
        // add total price to the row
        $product_per_user["total"] = $product_per_user["QRing"] + $product_per_user["QEarrings"] + $product_per_user["QPendant"] + $product_per_user["QChain"];
        
        // save the row in the new array
        $products_per_user1[] = $product_per_user;
        
        $All_ring1 = $All_ring1 + $product_per_user["QRing"];
        $All_earrings1 = $All_earrings1 + $product_per_user["QEarrings"];
        $All_pendant1 = $All_pendant1 + $product_per_user["QPendant"];
        $All_chanes1 = $All_chanes1 + $product_per_user["QChain"];
        $All1 = $All1 + $product_per_user["total"];
        
    }
    
    // count user's reserved product
    $rows2 =	CS50::query("Select U.username as user,
    (Select SUM(quantity) FROM Product WHERE type_id=1 AND presence_id=2 AND user_id = U.id) as QRing,
    (Select SUM(quantity) FROM Product WHERE type_id=2 AND presence_id=2 AND user_id = U.id) as QEarrings,
    (Select SUM(quantity) FROM Product WHERE type_id=3 AND presence_id=2 AND user_id = U.id) as QPendant,
    (Select SUM(quantity) FROM Product WHERE type_id=4 AND presence_id=2 AND user_id = U.id) as QChain From users U");	
	
	$All_ring2 = 0; $All_earrings2 = 0; $All_pendant2 = 0; $All_chanes2 = 0; $All2 = 0;
	
	// create new array to store all info for portfolio table
	$products_per_user2 = [];
	// for each of user's products
	foreach ($rows2 as $row)	
    {   
        // add user to the row
        $product_per_user["user"] = $row["user"];
        
        // add QRing to the row
        $product_per_user["QRing"] = $row["QRing"];
        
        // add QEarrings to the row
        $product_per_user["QEarrings"] = $row["QEarrings"];
        
        // add QPendant to the row
        $product_per_user["QPendant"] = $row["QPendant"];
        
        // add QChain to the row
        $product_per_user["QChain"] = $row["QChain"];
        
        // add total price to the row
        $product_per_user["total"] = $product_per_user["QRing"] + $product_per_user["QEarrings"] + $product_per_user["QPendant"] + $product_per_user["QChain"];
        
        // save the row in the new array
        $products_per_user2[] = $product_per_user;
        
        $All_ring2 = $All_ring2 + $product_per_user["QRing"];
        $All_earrings2 = $All_earrings2 + $product_per_user["QEarrings"];
        $All_pendant2 = $All_pendant2 + $product_per_user["QPendant"];
        $All_chanes2 = $All_chanes2 + $product_per_user["QChain"];
        $All2 = $All2 + $product_per_user["total"];
        
    }
    
    // query user for login
    $users = CS50::query("SELECT * FROM users WHERE id = ?", $_SESSION["id"]);
    // render portfolio 
    render("managers_form.php", ["title" => "Менеджеры", "products_per_user" => $products_per_user,
    "All_ring" => $All_ring, "All_earrings" => $All_earrings, "All_pendant" => $All_pendant,
    "All_chanes" => $All_chanes, "All" => $All, "products_per_user1" => $products_per_user1,
    "All_ring1" => $All_ring1, "All_earrings1" => $All_earrings1, "All_pendant1" => $All_pendant1,
    "All_chanes1" => $All_chanes1, "All1" => $All1, "products_per_user2" => $products_per_user2,
    "All_ring2" => $All_ring2, "All_earrings2" => $All_earrings2, "All_pendant2" => $All_pendant2,
    "All_chanes2" => $All_chanes2, "All2" => $All2, "users" => $users]);
?>
