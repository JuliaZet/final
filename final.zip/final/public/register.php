<?php

    // configuration
    require("../includes/config.php");

    // if user reached page via GET (as by clicking a link or via redirect)
    if ($_SERVER["REQUEST_METHOD"] == "GET")
    {
        // query user for login
        $users = CS50::query("SELECT * FROM users WHERE id = ?", $_SESSION["id"]);
        // else render form
        render("register_form.php", ["title" => "Регистрация", "users" => $users]);
    }

    // else if user reached page via POST (as by submitting a form via POST)
    else if ($_SERVER["REQUEST_METHOD"] == "POST")
    {
        // validate submission
        if (empty($_POST["username"]))
        {
            apologize("Укажите свой логин!");
        }
        else if (empty($_POST["password"]))
        {
            apologize("Укажите свой пароль!");
        }
        else if (empty($_POST["confirmation"]))
        {
            apologize("Подтвердите свой пароль!");
        }
        // compare password and confirmation
            if ($_POST["password"] == $_POST["confirmation"])
            {
               $result = CS50::query("INSERT IGNORE INTO users (username, hash) VALUES(?, ?)", $_POST["username"], password_hash($_POST["password"], PASSWORD_DEFAULT));
               // if insert is successful
                if ($result == false)
                {
                    apologize("Этот пользователь уже зарегистрирован!");
                }
                else
                {
                    $rows = CS50::query("SELECT LAST_INSERT_ID() AS id");
                    $id = $rows[0]["id"];
                    
                    // first (and only) row
                    $row = $rows[0];
                    
                    // remember that user's now logged in by storing user's ID in session
                    $_SESSION["id"] = $row["id"];

                    // redirect to index.php
                    redirect("managers.php");
                }
            }
            else
            {
                apologize("Пароли не совпадают!");
            }
    }


?>