<?php
    // configuration
    require("../includes/config.php");  
    
    // if form is submitted
    if ($_SERVER["REQUEST_METHOD"] == "POST") 
    {
        
        if (isset($_POST['create_product'])) {
            

            // validate submission
            if (empty($_POST["producer"]))
            {
                apologize("Укажите производителя!");
            }
            else if (empty($_POST["type"]))
            {
                apologize("Укажите тип изделия!");
            }
            else if (empty($_POST["articul"]))
            {
                apologize("Укажите артикул!");
            }
            else if (empty($_POST["metal"]))
            {
                apologize("Укажите металл!" );
            }
            else if (empty($_POST["gender"]))
            {
                apologize("Укажите для кого предназначено изделие!");
            }
            else if (empty($_POST["presence"]))
            {
                apologize("Укажите статус!");
            }
            else if (empty($_POST["price"]))
            {
                apologize("Укажите закупочную цену !");
            }
            else if (empty($_POST["user1"]))
            {
                apologize("Укажите менеджера!");
            }
            else if (empty($_POST["quantity"]))
            {
                apologize("Укажите количество изделий!" );
            }
            else if (empty($_POST["gem"]))
            {
                apologize("Укажите вставку!");
            }
            //else if (empty($_POST["gem_quantity"]))
            //{
            //    apologize("Укажите количество вставок!" );
            //}
            else
            {
                $ar=explode(" ", $_POST["gem"]);
                $ar_m=explode(" ", $_POST["metal"]);

                $p_result = CS50::query("SELECT id FROM Producer WHERE name = ?", $_POST["producer"]);
                $t_result = CS50::query("SELECT id FROM Product_type  WHERE type_name = ?", $_POST["type"]);
                $pr_result = CS50::query("SELECT id FROM Presence  WHERE presence = ?", $_POST["presence"]);
                $u_result = CS50::query("SELECT id FROM users WHERE username = ?", $_POST["user1"]);
                $g_result = CS50::query("SELECT DISTINCT G.id FROM Gems as G, Material as M, Color as C, Shape as S 
                        WHERE G.material_id=M.id AND M.name = '$ar[0]' AND G.color_id=C.id AND C.name = '$ar[1]' 
                        AND G.shape_id=S.id AND S.name = '$ar[2]' AND G.size = '$ar[3]'");
                $m_result = CS50::query("SELECT id FROM Metal  WHERE name = ? AND probe = ?", $ar_m[0], $ar_m[1]);
                $ge_result = CS50::query("SELECT id FROM Gender  WHERE name = ?", $_POST["gender"]);

                CS50::query("INSERT INTO Product (producer_id, type_id, articul, size, size_common, weight, presence_id, 
                price, price_sell, user_id, quantity, gem_id, gem_quantity, metal_id, gender_id) 
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)", $p_result[0]["id"], $t_result[0]["id"], $_POST["articul"],
                $_POST["size"], $_POST["size_common"], $_POST["weight"], $pr_result[0]["id"], $_POST['price'], $_POST['price_sell'],
                $u_result[0]["id"], $_POST["quantity"], $g_result[0]["id"], $_POST["gem_quantity"], $m_result[0]["id"], $ge_result[0]["id"]);
                
                //redirect to index, reserved or sold page
                if ($_POST["presence"] == 'Available')
                {
                     redirect("/index.php");
                }
                else if ($_POST["presence"] == 'Reserved')
                {
                     redirect("/reserved.php");
                } 
                else if ($_POST["presence"] == 'Not available')
                {
                     redirect("/sold.php");
                } 
            }
        }
        
        if (isset($_POST['create_producer'])) {
            
            // validate submission
            if (empty($_POST["producer"]))
            {
                apologize("Укажите название производителя!");
            }
            else
            {
                CS50::query("INSERT INTO Producer (name) VALUES (?)", $_POST['producer']);
                redirect("/edit.php"); 
            }
        }
        
        if (isset($_POST['create_type'])) {
            
            // validate submission
            if (empty($_POST["type"]))
            {
                apologize("Укажите название типа изделия!");
            }
            else
            {
                CS50::query("INSERT INTO Product_type (type_name) VALUES (?)", $_POST['type']);
                redirect("/edit.php"); 
            }
        } 
        
        if (isset($_POST['create_metal'])) {
                        
            // validate submission
            if (empty($_POST["metal"]))
            {
                apologize("Укажите название металла!");
            }
            else if (empty($_POST["probe"]))
            {
                apologize("Укажите пробу!");
            }
            else
            {
                CS50::query("INSERT INTO Metal (name, probe) VALUES (?,?)", $_POST['metal'], $_POST['probe']);
               redirect("/edit.php"); 
            }
        }
        
        if (isset($_POST['create_presence'])) {
                        
            // validate submission
            if (empty($_POST["presence"]))
            {
                apologize("Укажите название статуса!");
            }
            else
            {
                CS50::query("INSERT INTO Presence (presence) VALUES (?)", $_POST['presence']);
               redirect("/edit.php"); 
            }
        } 
        
        if (isset($_POST['create_gem'])) {
            
            // validate submission
            if (empty($_POST["material"]))
            {
                apologize("Укажите материал вставки!");
            }
            else if (empty($_POST["color"]))
            {
                apologize("Укажите цвет вставки!");
            }
            else if (empty($_POST["shape"]))
            {
                apologize("Укажите форму вставки!");
            }
            else if (empty($_POST["gem_size"]))
            {

                apologize("Укажите размер вставки!" );
            }
            else
            {
                $m_result = CS50::query("SELECT id FROM Material  WHERE name = ?", $_POST["material"]);
                $c_result = CS50::query("SELECT id FROM Color  WHERE name = ?", $_POST["color"]);
                $s_result = CS50::query("SELECT id FROM Shape  WHERE name = ?", $_POST["shape"]);
                
                CS50::query("INSERT INTO Gems (material_id, color_id, shape_id, size) VALUES (?, ?, ?, ?)", $m_result[0]["id"], $c_result[0]["id"], $s_result[0]["id"], $_POST['gem_size']);
                redirect("/edit.php"); 
            }
        }
        
        if (isset($_POST['create_material'])) {
            
            // validate submission
            if (empty($_POST["name"]))
            {
                apologize("Укажите название материала!");
            }
            else
            {
                CS50::query("INSERT INTO Material (name) VALUES (?)", $_POST['name']);
                redirect("/edit.php"); 
            }
        } 
        
        if (isset($_POST['create_color'])) {
                        
            // validate submission
            if (empty($_POST["name"]))
            {
                apologize("Укажите название цвета!");
            }
            else
            {
                CS50::query("INSERT INTO Color (name) VALUES (?)", $_POST['name']);
               redirect("/edit.php"); 
            }
        } 
        
        if (isset($_POST['create_shape'])) {
                        
            // validate submission
            if (empty($_POST["name"]))
            {
                apologize("Укажите название формы!");
            }
            else
            {
                CS50::query("INSERT INTO Shape (name) VALUES (?)", $_POST['name']);
               redirect("/edit.php"); 
            }
        } 
            
        
    }
    
    // if form hasn't been submitted
    else
    {
        // query producer
        $rows =	CS50::query("SELECT name as producer FROM Producer");	
        // create new array to store stock symbols
        $producers = [];
        // for each of user's stocks
        foreach ($rows as $row)	
        {   
            // save stock symbol
            $producer = $row["producer"];
            
            // add stock symbol to the new array
            $producers[] = $producer;       
        }
        
        // query type
        $rows =	CS50::query("SELECT type_name FROM Product_type");	
        // create new array to store stock symbols
        $types = [];
        // for each of user's stocks
        foreach ($rows as $row)	
        {   
            // save stock symbol
            $type = $row["type_name"];
            
            // add stock symbol to the new array
            $types[] = $type;       
        } 
        
        // query metal
        $rows =	CS50::query("SELECT name as metal, probe FROM Metal");	
        // create new array to store stock symbols
        $metals = [];
        // for each of user's stocks
        foreach ($rows as $row)	
        {   
            // save stock symbol
            $metal = $row["metal"] . ' ' . $row["probe"];
            
            // add stock symbol to the new array
            $metals[] = $metal;       
        }
        
        // query gender
        $rows =	CS50::query("SELECT name as gender FROM Gender");	
        // create new array to store stock symbols
        $genders = [];
        // for each of user's stocks
        foreach ($rows as $row)	
        {   
            // save stock symbol
            $gender = $row["gender"];
            
            // add stock symbol to the new array
            $genders[] = $gender;       
        }
        
        // query presence
        $rows =	CS50::query("SELECT presence FROM Presence");	
        // create new array to store stock symbols
        $presences = [];
        // for each of user's stocks
        foreach ($rows as $row)	
        {   
            // save stock symbol
            $presence = $row["presence"];
            
            // add stock symbol to the new array
            $presences[] = $presence;       
        } 
        
        // query user
        $rows =	CS50::query("SELECT username FROM users");	
        // create new array to store stock symbols
        $users1 = [];
        // for each of user's stocks
        foreach ($rows as $row)	
        {   
            // save stock symbol
            $user1 = $row["username"];
            
            // add stock symbol to the new array
            $users1[] = $user1;       
        } 
        
        // query gem
        $rows =	CS50::query("SELECT G.*, M.name as material, C.name as color, S.name as shape 
                    FROM Gems as G inner join Material as M on G.material_id=M.id
                    inner join Color as C on G.color_id=C.id
                    inner join Shape as S on G.shape_id=S.id");	
        // create new array to store stock symbols
        $gems = [];
        // for each of user's stocks
        foreach ($rows as $row)	
        {   
            // save stock symbol
            $gem = $row["material"] . ' ' . $row["color"] . ' ' . $row["shape"] . ' ' . $row["size"];
            
            // add stock symbol to the new array
            $gems[] = $gem;       
        }
        
        // query color
        $rows =	CS50::query("SELECT name FROM Material");	
        // create new array to store stock symbols
        $materials = [];
        // for each of user's stocks
        foreach ($rows as $row)	
        {   
            // save stock symbol
            $material = $row["name"];
            
            // add stock symbol to the new array
            $materials[] = $material;       
        } 
        
        // query color
        $rows =	CS50::query("SELECT name FROM Color");	
        // create new array to store stock symbols
        $colors = [];
        // for each of user's stocks
        foreach ($rows as $row)	
        {   
            // save stock symbol
            $color = $row["name"];
            
            // add stock symbol to the new array
            $colors[] = $color;       
        } 
        
        // query shape
        $rows =	CS50::query("SELECT name FROM Shape");	
        // create new array to store stock symbols
        $shapes = [];
        // for each of user's stocks
        foreach ($rows as $row)	
        {   
            // save stock symbol
            $shape = $row["name"];
            
            // add stock symbol to the new array
            $shapes[] = $shape;       
        } 
        
        // query cash for template
    $users = CS50::query("SELECT * FROM users WHERE id = ?", $_SESSION["id"]);
    // render portfolio (pass in new portfolio table and cash)
    render("edit_form.php", ["title" => "Редактирование", "users" => $users, "producers" => $producers,
     "types" => $types, "metals" => $metals, "genders" => $genders, "presences" => $presences, "users1" => $users1, "gems" => $gems,
     "materials" => $materials, "colors" => $colors, "shapes" => $shapes]);

    }
      
?>