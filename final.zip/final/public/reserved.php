<?php
    // configuration
    require("../includes/config.php"); 
    // query user's portfolio
   $rows =	CS50::query("select P.*, Pr.name as producer, PT.type_name, Ps.presence, U.username, G.name as gender,
                        M.name as metal, M.probe
                        from Product as P inner join Producer as Pr on Pr.id = P.producer_id
                        inner join Product_type as PT on PT.id = P.type_id
                        inner join Presence as Ps on Ps.id = P.presence_id
                        inner join users as U on U.id = P.user_id
                        inner join Gender as G on G.id = P.gender_id
                        inner join Metal as M on M.id = P.metal_id
                        where Ps.id = 2");	
	// create new array to store all info for portfolio table
	$portfolio = [];
	// for each of products
	foreach ($rows as $row)	
    {   
        // lookup info at row
        $product["id"] = $row["id"];
        
        $product["producer"] = $row["producer"];
        if ($product["producer"] == "Gloria")
        {
            $product["producer"] = "Глория";
        }
        else if ($product["producer"] == "Rubin")
        {
            $product["producer"] = "Рубин";
        }

        $product["type"] = $row["type_name"];
        if ($product["type"] == "Ring")
        {
            $product["type"] = "Кольцо";
        }
        else if ($product["type"] == "Earrings")
        {
            $product["type"] = "Серьги";
        }
        else if ($product["type"] == "Pendant")
        {
            $product["type"] = "Подвес";
        }
        else if ($product["type"] == "Chain")
        {
            $product["type"] = "Цепочка";
        }
        
        $product["presence"] = $row["presence"];

        $product["user"] = $row["username"];
        
        $product["gender"] = $row["gender"];

        $product["metal"] = $row["metal"];
        if ($product["metal"] == "Silver")
        {
            $product["metal"] = "Серебро";
        }
        
        $product["probe"] = $row["probe"];
        
        $product["price"] = $row["price"];

        $product["articul"] = $row["articul"];
        
        $product["size"] = $row["size"];
        /*if ($product["size"] == "NULL")
        {
            $product["size"] = "";
        }*/

        $product["size_common"] = $row["size_common"];
        
        $product["weight"] = $row["weight"];

        $product["quantity"] = $row["quantity"];
        
        $product["gem_quantity"] = $row["gem_quantity"];

        // save the row in the new array
        $portfolio[] = $product;
    }

    if ($_SERVER['REQUEST_METHOD'] == 'POST') {

    if (isset($_POST['cancel'])) {

        $rowToDelete = intval($_POST['cancel']);

        CS50::query("UPDATE Product SET presence_id = 1 WHERE id = ?", $rowToDelete); 
        redirect("/"); 

        }
    
    if (isset($_POST['sell_b'])) {

        $rowToDelete = intval($_POST['sell_b']);
        $u_result = CS50::query("SELECT id FROM users WHERE username = ?", $_POST["sell_user"]);
        $quant = CS50::query("SELECT quantity FROM Product WHERE id = ?", $rowToDelete);

        if ( $quant[0]["quantity"] > $_POST["sell_quantity"])
        {
            $q = $quant[0]["quantity"]; //- $_POST["sell_quantity"];
            
            CS50::query("INSERT INTO Product_sold (product_id, data, price_s, user_id, quantity_s) 
                VALUES (?, Now(), ?, ?, ?)", $rowToDelete, $_POST["price_sell"],
                $u_result[0]["id"], $_POST["sell_quantity"]);
            CS50::query("UPDATE Product SET presence_id = 1, quantity = ? WHERE id = ?", $q, $rowToDelete); 
            redirect("/sold.php");
        }
        else if ( $quant[0]["quantity"] = $_POST["sell_quantity"])
        {
            $q = $quant[0]["quantity"] - $_POST["sell_quantity"];
            
            CS50::query("INSERT INTO Product_sold (product_id, data, price_s, user_id, quantity_s) 
                VALUES (?, Now(), ?, ?, ?)", $rowToDelete, $_POST["price_sell"],
                $u_result[0]["id"], $_POST["sell_quantity"]);
            CS50::query("UPDATE Product SET presence_id = 3, quantity = ? WHERE id = ?", $q, $rowToDelete); 
            redirect("/sold.php");
        }
        else if ( $quant[0]["quantity"] < $_POST["sell_quantity"])
        {
            apologize("Недостаточно изделий в наличии!");
        }
}
    }
        // query user
        $rows =	CS50::query("SELECT username FROM users");	
        // create new array 
        $users1 = [];
        // for each of users
        foreach ($rows as $row)	
        {   
            // save 
            $user1 = $row["username"];
            
            // add  to the new array
            $users1[] = $user1;       
        } 

    // query user for login
    $users = CS50::query("SELECT * FROM users WHERE id = ?", $_SESSION["id"]);
    // render portfolio 
    render("reserved_form.php", ["title" => "Резерв", "portfolio" => $portfolio, "users" => $users, "users1" => $users1]);
?>