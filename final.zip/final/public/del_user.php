<?php
    // configuration
    require("../includes/config.php");  
    
    // if form is submitted
    if ($_SERVER["REQUEST_METHOD"] == "POST") 
    {

        $chosen = CS50::query("SELECT * FROM users WHERE username = ?", $_POST["username"]);
        if ($_POST["username"] == $chosen[0]["username"])
        {
            CS50::query("DELETE FROM users WHERE id = ?", $chosen[0]["id"]);
        }
       // redirect to portfolio 
        redirect("/");
    }
    
    // if form hasn't been submitted
    else
    {
        // query users
        $rows = CS50::query("SELECT * FROM users");	
        
        $del_users = [];
        // for each of user
        foreach ($rows as $row)	
        {   
            // save user's name
            $user = $row["username"];

            // add user's name to the new array
            $del_users[] = $user;       
        } 
        
        // query user
        $users = CS50::query("SELECT * FROM users WHERE id = ?", $_SESSION["id"]);
        // render del user form
        render("del_user_form.php", ["title" => "Del Form", "del_users" => $del_users, "users" => $users]);
        
    }
      
?>