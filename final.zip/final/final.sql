-- MySQL dump 10.13  Distrib 5.5.49, for debian-linux-gnu (x86_64)
--
-- Host: 0.0.0.0    Database: final
-- ------------------------------------------------------
-- Server version	5.5.49-0ubuntu0.14.04.1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `Color`
--

DROP TABLE IF EXISTS `Color`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Color` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Color`
--

LOCK TABLES `Color` WRITE;
/*!40000 ALTER TABLE `Color` DISABLE KEYS */;
INSERT INTO `Color` VALUES (1,''),(2,'white'),(3,'black'),(4,'green'),(5,'blue'),(6,'red');
/*!40000 ALTER TABLE `Color` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Gems`
--

DROP TABLE IF EXISTS `Gems`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Gems` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `material_id` int(10) unsigned NOT NULL,
  `color_id` int(10) unsigned NOT NULL,
  `shape_id` int(10) unsigned NOT NULL,
  `size` varchar(100) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `shape_id` (`shape_id`),
  KEY `color_id` (`color_id`),
  KEY `material_id` (`material_id`),
  CONSTRAINT `Gems_color_fk` FOREIGN KEY (`color_id`) REFERENCES `Color` (`id`) ON UPDATE CASCADE,
  CONSTRAINT `Gems_material_fk` FOREIGN KEY (`material_id`) REFERENCES `Material` (`id`) ON UPDATE CASCADE,
  CONSTRAINT `Gems_shape_fk` FOREIGN KEY (`shape_id`) REFERENCES `Shape` (`id`) ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Gems`
--

LOCK TABLES `Gems` WRITE;
/*!40000 ALTER TABLE `Gems` DISABLE KEYS */;
INSERT INTO `Gems` VALUES (1,1,1,1,''),(2,2,2,2,'1'),(3,2,2,2,'4x4'),(4,2,6,2,'5x5'),(5,3,3,4,'3x2'),(6,3,2,2,'8'),(7,5,3,5,'45x2');
/*!40000 ALTER TABLE `Gems` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Gender`
--

DROP TABLE IF EXISTS `Gender`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Gender` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Gender`
--

LOCK TABLES `Gender` WRITE;
/*!40000 ALTER TABLE `Gender` DISABLE KEYS */;
INSERT INTO `Gender` VALUES (1,'Female'),(2,'Male'),(3,'For all');
/*!40000 ALTER TABLE `Gender` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Material`
--

DROP TABLE IF EXISTS `Material`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Material` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Material`
--

LOCK TABLES `Material` WRITE;
/*!40000 ALTER TABLE `Material` DISABLE KEYS */;
INSERT INTO `Material` VALUES (1,''),(2,'Phianite'),(3,'Pearl'),(4,'Ulexit'),(5,'Kauchuck');
/*!40000 ALTER TABLE `Material` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Metal`
--

DROP TABLE IF EXISTS `Metal`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Metal` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `probe` int(10) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Metal`
--

LOCK TABLES `Metal` WRITE;
/*!40000 ALTER TABLE `Metal` DISABLE KEYS */;
INSERT INTO `Metal` VALUES (1,'Silver',925),(2,'Silver',875);
/*!40000 ALTER TABLE `Metal` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Presence`
--

DROP TABLE IF EXISTS `Presence`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Presence` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `presence` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Presence`
--

LOCK TABLES `Presence` WRITE;
/*!40000 ALTER TABLE `Presence` DISABLE KEYS */;
INSERT INTO `Presence` VALUES (1,'Available'),(2,'Reserved'),(3,'Not available');
/*!40000 ALTER TABLE `Presence` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Producer`
--

DROP TABLE IF EXISTS `Producer`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Producer` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Producer`
--

LOCK TABLES `Producer` WRITE;
/*!40000 ALTER TABLE `Producer` DISABLE KEYS */;
INSERT INTO `Producer` VALUES (1,'Gloria'),(2,'Rubin');
/*!40000 ALTER TABLE `Producer` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Product`
--

DROP TABLE IF EXISTS `Product`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Product` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `producer_id` int(10) unsigned NOT NULL,
  `type_id` int(10) unsigned NOT NULL,
  `articul` varchar(100) NOT NULL,
  `photo` text,
  `size` int(10) DEFAULT NULL,
  `size_common` varchar(100) DEFAULT NULL,
  `weight` float DEFAULT NULL,
  `presence_id` int(10) unsigned NOT NULL,
  `price` int(10) NOT NULL,
  `price_sell` int(10) DEFAULT NULL,
  `user_id` int(10) unsigned NOT NULL,
  `quantity` int(10) NOT NULL DEFAULT '1',
  `gem_id` int(10) unsigned NOT NULL DEFAULT '1',
  `gem_quantity` int(10) DEFAULT '0',
  `metal_id` int(10) unsigned NOT NULL DEFAULT '1',
  `gender_id` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `producer_id` (`producer_id`),
  KEY `type_id` (`type_id`),
  KEY `presence_id` (`presence_id`),
  KEY `user_id` (`user_id`),
  KEY `gem_id` (`gem_id`),
  KEY `metal_id` (`metal_id`),
  KEY `gender_id` (`gender_id`),
  CONSTRAINT `Product_gems_fk` FOREIGN KEY (`gem_id`) REFERENCES `Gems` (`id`) ON UPDATE CASCADE,
  CONSTRAINT `Product_gender_fk` FOREIGN KEY (`gender_id`) REFERENCES `Gender` (`id`) ON UPDATE CASCADE,
  CONSTRAINT `Product_metal_fk` FOREIGN KEY (`metal_id`) REFERENCES `Metal` (`id`) ON UPDATE CASCADE,
  CONSTRAINT `Product_presence_fk` FOREIGN KEY (`presence_id`) REFERENCES `Presence` (`id`) ON UPDATE CASCADE,
  CONSTRAINT `Product_producer_fk` FOREIGN KEY (`producer_id`) REFERENCES `Producer` (`id`) ON UPDATE CASCADE,
  CONSTRAINT `Product_producttype_fk` FOREIGN KEY (`type_id`) REFERENCES `Product_type` (`id`) ON UPDATE CASCADE,
  CONSTRAINT `Product_user_fk` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Product`
--

LOCK TABLES `Product` WRITE;
/*!40000 ALTER TABLE `Product` DISABLE KEYS */;
INSERT INTO `Product` VALUES (1,1,1,'502',NULL,20,'21x11',2.41,3,80,NULL,3,0,2,28,1,1),(2,2,2,'2027',NULL,NULL,'30x10',3.84,1,350,NULL,2,1,1,54,1,1),(3,1,1,'202',NULL,19,'21x11',2.41,1,85,NULL,3,1,2,28,1,1),(5,1,2,'48',NULL,0,'30x10',5.44,1,300,0,2,2,2,5,1,1),(6,1,3,'502',NULL,0,'60x30',9.11,3,200,0,2,0,1,NULL,1,3),(7,2,4,'4012',NULL,18,'18x5',6.44,2,250,0,3,1,1,0,1,3),(8,1,3,'3117',NULL,0,'27x15',1.22,1,150,0,3,4,1,0,1,3),(9,1,1,'320',NULL,18,'19x8',1.98,1,165,0,3,1,6,1,1,1),(10,1,2,'260',NULL,0,'14x7',2.33,1,210,0,3,2,3,2,1,1),(11,2,4,'4008',NULL,45,'45x2',0.75,1,100,0,1,1,7,1,1,3);
/*!40000 ALTER TABLE `Product` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Product_gems`
--

DROP TABLE IF EXISTS `Product_gems`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Product_gems` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `product_id` int(10) unsigned NOT NULL,
  `gems_id` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `product_id` (`product_id`),
  KEY `gems_id` (`gems_id`),
  CONSTRAINT `ProductGems_gems_fk` FOREIGN KEY (`gems_id`) REFERENCES `Gems` (`id`) ON UPDATE CASCADE,
  CONSTRAINT `ProductGems_product_fk` FOREIGN KEY (`product_id`) REFERENCES `Product` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Product_gems`
--

LOCK TABLES `Product_gems` WRITE;
/*!40000 ALTER TABLE `Product_gems` DISABLE KEYS */;
/*!40000 ALTER TABLE `Product_gems` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Product_sold`
--

DROP TABLE IF EXISTS `Product_sold`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Product_sold` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `product_id` int(10) unsigned NOT NULL,
  `data` date NOT NULL,
  `price_s` int(10) DEFAULT NULL,
  `user_id` int(10) unsigned NOT NULL,
  `quantity_s` int(10) NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`),
  KEY `product_id` (`product_id`),
  KEY `user_id` (`user_id`),
  CONSTRAINT `ProductSold_product_fk` FOREIGN KEY (`product_id`) REFERENCES `Product` (`id`) ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Product_sold`
--

LOCK TABLES `Product_sold` WRITE;
/*!40000 ALTER TABLE `Product_sold` DISABLE KEYS */;
INSERT INTO `Product_sold` VALUES (1,5,'2016-12-19',350,2,5),(7,3,'2016-12-19',100,3,1),(8,3,'2016-12-19',110,2,1),(9,5,'2016-12-19',400,3,1);
/*!40000 ALTER TABLE `Product_sold` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Product_type`
--

DROP TABLE IF EXISTS `Product_type`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Product_type` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `type_name` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Product_type`
--

LOCK TABLES `Product_type` WRITE;
/*!40000 ALTER TABLE `Product_type` DISABLE KEYS */;
INSERT INTO `Product_type` VALUES (1,'Ring'),(2,'Earrings'),(3,'Pendant'),(4,'Chain');
/*!40000 ALTER TABLE `Product_type` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Shape`
--

DROP TABLE IF EXISTS `Shape`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Shape` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Shape`
--

LOCK TABLES `Shape` WRITE;
/*!40000 ALTER TABLE `Shape` DISABLE KEYS */;
INSERT INTO `Shape` VALUES (1,''),(2,'Circle'),(3,'Drop'),(4,'Triangle'),(5,'Baget');
/*!40000 ALTER TABLE `Shape` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `users` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `username` varchar(255) NOT NULL,
  `hash` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES (1,'skroob','$2y$10$395b7wODm.o2N7W5UZSXXuXwrC0OtFB17w4VjPnCIn/nvv9e4XUQK'),(2,'Kate','$2y$10$54oU4MxIN/6BmgZZ.Um7QOiGv/RfJ7u764E8N4OysqNWpBxZlEjNC'),(3,'Dan','$2y$10$iLAjZvveL3AHkC/b2PYM7.DHMob12WgZzObZjoccJCm7phqjJhG32'),(5,'d','$2y$10$HN.L5ziPJu7WZbACaMZ5SuRgPVUUa/ggniFHKTakl4nU3StRkmLse');
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2016-12-19 14:26:46
