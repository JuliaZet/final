<div class="container">

            <div id="top">
                

            </div>

            
            <div id="middle">  


<form id="for">
    <h1>Sorry!</h1>
    <p><?= htmlspecialchars($message) ?></p>
    <div class="form-group">
            <button class="btn btn-default" type="submit">
                
                <i class="fa"></i> Назад
            </button>
        </div>
</form>