<div class="container">

            <div id="top">
                
            </div>

            
            <div id="middle"> 


<form id="for" action="del_user.php" method="post">
    <fieldset>
        <div class="form-group">
            <select autocomplete="off" autofocus class="form-control" name="User">
                
                <?php               
	                foreach ($del_users as $username)	
                    {   
                        echo("<option value='$username'>" . $username . "</option>");
                    }
                ?>
            </select>
        </div>
        
        <div class="form-group">
            <button class="btn btn-default" type="submit">
                <span aria-hidden="true" class="glyphicon "></span>
                Удалить менеджера
            </button>
        </div>
    </fieldset>
</form>