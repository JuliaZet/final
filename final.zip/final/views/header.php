<!DOCTYPE html>

<html>

    <head>

        <!-- http://getbootstrap.com/ -->
        <link href="/css/bootstrap.min.css" rel="stylesheet"/>

        <link href="/css/styles.css" rel="stylesheet"/>

        <?php if (isset($title)): ?>
            <title>Глори: <?= htmlspecialchars($title) ?></title>
        <?php else: ?>
            <title>Глори</title>
        <?php endif ?>

        <!-- https://jquery.com/ -->
        <script src="/js/jquery-1.11.3.min.js"></script>

        <!-- http://getbootstrap.com/ -->
        <script src="/js/bootstrap.min.js"></script>

        <script src="/js/scripts.js"></script>

    </head>

    <body>
                <div style="background:#082340; height:120px; ">
                    
                    <div style="float:left; margin-top: 10px; margin-left: 40px">
                        <a href="/"><img alt="logo" src="/img/glori-5.png"/></a>
                    </div>
                    
                    <div style="float:right; margin:40px;">
                        <?php if (!empty($_SESSION["id"])): ?>
                        <ul class="nav nav-pills" style="vertical-align:middle;">
                            <li><a href="index.php">Главная</a></li>
                            <li><a href="reserved.php">Резерв</a></li>
                            <li><a href="sold.php">Продано</a></li>
                            <li><a href="edit.php">Добавить</a></li>
                            <li><a href="managers.php">Менеджеры</a></li>
                            <li><a href="logout.php"><strong><?=$users[0]["username"]?>! Выйти</strong></a></li>;
                            
                        </ul>
                        <?php endif ?>
                    </div>
                </div>

