<style>
    /* Базовые стили слоя затемнения и модального окна  */
.overlay {
    top: 0;
    right: 0;
    bottom: 0;
    left: 0;
    z-index: 10;
    display: none;
/* фон затемнения */
    background-color: rgba(0, 0, 0, 0.65);
    position: fixed; /* фиксированное поцизионирование */
    cursor: default; /* тип курсара */
}
/* активируем слой затемнения */
.overlay:target {
    display: block;
}
/* стили модального окна */
.popup {
    top: -100%;
    right: 0;
    left: 50%;
    font-size: 14px;
    z-index: 20;
    margin: 0;
    width: 85%;
    min-width: 320px;
    max-width: 600px;
/* фиксированное позиционирование, окно стабильно при прокрутке */
    position: fixed;
    padding: 15px;
    border: 1px solid #383838;
    background: #fefefe;
/* скругление углов */
    -webkit-border-radius: 4px;
    -moz-border-radius: 4px;
    -ms-border-radius: 4px;
    border-radius: 4px;
    font: 14px/18px 'Tahoma', Arial, sans-serif;
/* внешняя тень */
    -webkit-box-shadow: 0 15px 20px rgba(0,0,0,.22),0 19px 60px rgba(0,0,0,.3);
    -moz-box-shadow: 0 15px 20px rgba(0,0,0,.22),0 19px 60px rgba(0,0,0,.3);
    -ms-box-shadow: 0 15px 20px rgba(0,0,0,.22),0 19px 60px rgba(0,0,0,.3);
    box-shadow: 0 15px 20px rgba(0,0,0,.22),0 19px 60px rgba(0,0,0,.3);
    -webkit-transform: translate(-50%, -500%);
    -ms-transform: translate(-50%, -500%);
    -o-transform: translate(-50%, -500%);
    transform: translate(-50%, -500%);
    -webkit-transition: -webkit-transform 0.6s ease-out;
    -moz-transition: -moz-transform 0.6s ease-out;
    -o-transition: -o-transform 0.6s ease-out;
    transition: transform 0.6s ease-out;
}
/* активируем модальный блок */
.overlay:target+.popup {
    -webkit-transform: translate(-50%, 0);
    -ms-transform: translate(-50%, 0);
    -o-transform: translate(-50%, 0);
    transform: translate(-50%, 0);
    top: 20%;
}
/* формируем кнопку закрытия */
.close {
    top: -10px;
    right: -10px;
    width: 20px;
    height: 20px;
    position: absolute;
    padding: 0;
    border: 2px solid #ccc;
    -webkit-border-radius: 15px;
    -moz-border-radius: 15px;
    -ms-border-radius: 15px;
    -o-border-radius: 15px;
    border-radius: 15px;
    background-color: rgba(61, 61, 61, 0.8);
    -webkit-box-shadow: 0px 0px 10px #000;
    -moz-box-shadow: 0px 0px 10px #000;
    box-shadow: 0px 0px 10px #000;
    text-align: center;
    text-decoration: none;
    font: 13px/20px 'Tahoma', Arial, sans-serif;
    font-weight: bold;
    -webkit-transition: all ease .8s;
    -moz-transition: all ease .8s;
    -ms-transition: all ease .8s;
    -o-transition: all ease .8s;
    transition: all ease .8s;
}
.close:before {
    color: rgba(255, 255, 255, 0.9);
    content: "X";
    text-shadow: 0 -1px rgba(0, 0, 0, 0.9);
    font-size: 12px;
}
.close:hover {
    background-color: rgba(252, 20, 0, 0.8);
    -webkit-transform: rotate(360deg);
    -moz-transform: rotate(360deg);
    -ms-transform: rotate(360deg);
    -o-transform: rotate(360deg);
    transform: rotate(360deg);    
}
/* изображения внутри окна */
.popup img {
    width: 100%;
    height: auto;
}
/* миниатюры слева/справа */
.pic-left, 
.pic-right {
    width: 25%;
    height: auto;
}
.pic-left {
    float: left;
    margin: 5px 15px 5px 0;
}
.pic-right {
    float: right;
    margin: 5px 0 5px 15px;
}
/* элементы м-медиа, фреймы */
.popup embed, 
.popup iframe {
    top: 0;
    right: 0;
    bottom: 0; 
    left: 0; 
    display:block;
    margin: auto;
    min-width: 320px;
    max-width: 600px;
    width: 100%;
}
.popup h2 { /* заголовок 2 */
    margin: 0;
    color: #008000;
    padding: 5px 0px 10px;
    text-align: left;
    text-shadow: 1px 1px 3px #adadad;
    font-weight: 500;
    font-size: 1.4em;
    font-family: 'Tahoma', Arial, sans-serif;
    line-height: 1.3;
}
/* параграфы */
.popup p {margin: 0; padding: 5px 0}
 
</style>


<div class="breadcrumbs">
    <ul>
        <li><a href="index.php">Главная</a> => <a href="edit.php">Добавить</a></li>
    </ul>
</div>
<?php if (!empty($_SESSION["id"])): ?>
                <div class="container"> 
                    <h3>Формы добавления новых данных</h3>
                </div>
                <?php endif ?>
            <div id="leftside">
                
                <?php if (!empty($_SESSION["id"])): ?>
                    <ul class="nav">
                        <li><a href="#">Изделие</a></li>
                        <li><a href="#add_producer">Производитель</a></li>
                        <li><a href="#add_type">Тип изделия</a></li>
                        <li><a href="#add_metal">Металл</a></li>
                        <li><a href="#add_presence">Статус</a></li>
                        <li><a href="#add_gem">Вставка</a></li>
                        <li><a href="#add_material">Материал вставки</a></li>
                        <li><a href="#add_color">Цвет вставки</a></li>
                        <li><a href="#add_shape">Форма вставки</a></li>
                    </ul>
                <?php endif ?>
            </div>


<div class="middlebar">
                
                <div id="middle"> 
<form id="for" action="edit.php" method="post" style="height:600px; margin-top: 0px; margin-bottom: 150px;">
    <div class="container"> <h4>Добавить изделие</h4></div>
    <fieldset style="width: 30%; float:left;">
        
        <!--<div class="form-group">
            <select autocomplete="off" autofocus class="form-control" name="producer" placeholder="Производитель">
                
                <?php               
	                foreach ($producers as $producer)	
                    {   
                        echo("<option value='$producer'>" . $producer . "</option>");
                    }
                ?>
            </select>
        </div>-->
        <div class="form-group">
            <select autocomplete="off" autofocus class="form-control" name="type" placeholder="Тип изделия">
                
                <?php               
	                foreach ($types as $type)	
                    {   
                        echo("<option value='$type'>" . $type . "</option>");
                    }
                ?>
            </select>
        </div>
        <div class="form-group">
            <input autocomplete="off" autofocus class="form-control" name="articul" placeholder="Артикул" type="text"/>
        </div>
        <div class="form-group">
            <input autocomplete="off" class="form-control" name="size" placeholder="Размер" type="text"/>
        </div>
        <div class="form-group">
            <input autocomplete="off" class="form-control" name="size_common" placeholder="Размер общий" type="text"/>
        </div>
        <div class="form-group">
            <input autocomplete="off" class="form-control" name="weight" placeholder="Вес" type="text"/>
        </div>
        <div class="form-group">
            <input autocomplete="off" class="form-control" name="quantity" placeholder="Количество" type="text"/>
        </div>
        <!--<div class="form-group">
            <select autocomplete="off" autofocus class="form-control" name="metal" placeholder="Металл">
                
                <?php               
	                foreach ($metals as $metal)	
                    {   
                        echo("<option value='$metal'>" . $metal . "</option>");
                    }
                ?>
            </select>
        </div>
        <div class="form-group">
            <select autocomplete="off" autofocus class="form-control" name="gender" placeholder="Для кого">
                
                <?php               
	                foreach ($genders as $gender)	
                    {   
                        echo("<option value='$gender'>" . $gender . "</option>");
                    }
                ?>
            </select>
        </div>
        <div class="form-group">
            <select autocomplete="off" autofocus class="form-control" name="presence" placeholder="Статус">
                
                <?php               
	                foreach ($presences as $presence)	
                    {   
                        echo("<option value='$presence'>" . $presence . "</option>");
                    }
                ?>
            </select>
        </div>
        <div class="form-group">
            <input autocomplete="off" class="form-control" name="price" placeholder="Закупочная цена" type="text"/>
        </div>
        <div class="form-group">
            <input autocomplete="off" class="form-control" name="price_sell" placeholder="Цена продажи" type="text"/>
        </div>
        <div class="form-group">
            <select autocomplete="off" autofocus class="form-control" name="user1" placeholder="Менеджер">
                
                <?php               
	                foreach ($users1 as $user1)	
                    {   
                        echo("<option value='$user1'>" . $user1 . "</option>");
                    }
                ?>
            </select>
        </div>
        
        <div class="form-group">
            <select autocomplete="off" autofocus class="form-control" name="gem" placeholder="Вставка">
                
                <?php               
	                foreach ($gems as $gem)	
                    {   
                        echo("<option value='$gem'>" . $gem . "</option>");
                    }
                ?>
            </select>
        </div>
        <div class="form-group">
            <input autocomplete="off" class="form-control" name="gem_quantity" placeholder="Количество вставок" type="text"/>
        </div>
        <div class="form-group">
            <button class="btn btn-default" type="submit" name="create_product">
                <span aria-hidden="true" class="glyphicon "></span>
                Buy
            </button>
        </div>-->
    </fieldset>
    <fieldset style="width: 1%; float:left; margin: 0 0.5%;">
        <!--<div class="form-group add">
            <a href="#add_producer" title="Добавить нового производителя">+</a>
        </div>-->
        <div class="form-group add">
            <a href="#add_type" title="Добавить новый тип изделия">+</a>
        </div>
        <div class="form-group add"></div>
        <div class="form-group add"></div>
        <div class="form-group add"></div>
        <div class="form-group add"></div>
        <div class="form-group add"></div>
        <!--<div class="form-group add">
            <a href="#add_metal" title="Добавить новый металл">+</a>
        </div>
        <div class="form-group add"></div>
        <div class="form-group add">
            <a href="#add_presence" title="Добавить новый статус">+</a>
        </div>
        <div class="form-group add"></div>
        <div class="form-group add"></div>
        <div class="form-group add"></div>
        
        <div class="form-group add">
            <a href="#add_gem" title="Добавить новую вставку">+</a>
        </div>-->
    </fieldset>
    
    <fieldset style="width: 30%; float:left; margin-left:2%">
        
        <div class="form-group">
            <select autocomplete="off" autofocus class="form-control" name="producer" placeholder="Производитель">
                
                <?php               
	                foreach ($producers as $producer)	
                    {   
                        echo("<option value='$producer'>" . $producer . "</option>");
                    }
                ?>
            </select>
        </div>
        <!--<div class="form-group">
            <select autocomplete="off" autofocus class="form-control" name="type" placeholder="Тип изделия">
                
                <?php               
	                foreach ($types as $type)	
                    {   
                        echo("<option value='$type'>" . $type . "</option>");
                    }
                ?>
            </select>
        </div>
        <div class="form-group">
            <input autocomplete="off" autofocus class="form-control" name="articul" placeholder="Артикул" type="text"/>
        </div>
        <div class="form-group">
            <input autocomplete="off" class="form-control" name="size" placeholder="Размер" type="text"/>
        </div>
        <div class="form-group">
            <input autocomplete="off" class="form-control" name="size_common" placeholder="Размер общий" type="text"/>
        </div>
        <div class="form-group">
            <input autocomplete="off" class="form-control" name="weight" placeholder="Вес" type="text"/>
        </div>
        <div class="form-group">
            <input autocomplete="off" class="form-control" name="quantity" placeholder="Количество" type="text"/>
        </div>-->
        <div class="form-group">
            <select autocomplete="off" autofocus class="form-control" name="metal" placeholder="Металл">
                
                <?php               
	                foreach ($metals as $metal)	
                    {   
                        echo("<option value='$metal'>" . $metal . "</option>");
                    }
                ?>
            </select>
        </div>
        <div class="form-group">
            <select autocomplete="off" autofocus class="form-control" name="gender" placeholder="Для кого">
                
                <?php               
	                foreach ($genders as $gender)	
                    {   
                        echo("<option value='$gender'>" . $gender . "</option>");
                    }
                ?>
            </select>
        </div>
        <div class="form-group">
            <select autocomplete="off" autofocus class="form-control" name="presence" placeholder="Статус">
                
                <?php               
	                foreach ($presences as $presence)	
                    {   
                        echo("<option value='$presence'>" . $presence . "</option>");
                    }
                ?>
            </select>
        </div>
        <div class="form-group">
            <input autocomplete="off" class="form-control" name="price" placeholder="Закупочная цена" type="text"/>
        </div>
        <div class="form-group">
            <input autocomplete="off" class="form-control" name="price_sell" placeholder="Цена продажи" type="text"/>
        </div>
        <div class="form-group">
            <select autocomplete="off" autofocus class="form-control" name="user1" placeholder="Менеджер">
                
                <?php               
	                foreach ($users1 as $user1)	
                    {   
                        echo("<option value='$user1'>" . $user1 . "</option>");
                    }
                ?>
            </select>
        </div>
        
        <!--<div class="form-group">
            <select autocomplete="off" autofocus class="form-control" name="gem" placeholder="Вставка">
                
                <?php               
	                foreach ($gems as $gem)	
                    {   
                        echo("<option value='$gem'>" . $gem . "</option>");
                    }
                ?>
            </select>
        </div>
        <div class="form-group">
            <input autocomplete="off" class="form-control" name="gem_quantity" placeholder="Количество вставок" type="text"/>
        </div>-->
        <div class="form-group">
            <button class="btn btn-default" type="submit" name="create_product">
                <span aria-hidden="true" class="glyphicon "></span>
                Создать
            </button>
        </div>
    </fieldset>
    <fieldset style="width: 1%; float:left; margin: 0 0.5%;">
        <div class="form-group add">
            <a href="#add_producer" title="Добавить нового производителя">+</a>
        </div>
        <!--<div class="form-group add">
            <a href="#add_type" title="Добавить новый тип изделия">+</a>
        </div>
        <div class="form-group add"></div>
        <div class="form-group add"></div>
        <div class="form-group add"></div>
        <div class="form-group add"></div>
        <div class="form-group add"></div>-->
        <div class="form-group add">
            <a href="#add_metal" title="Добавить новый металл">+</a>
        </div>
        <div class="form-group add"></div>
        <div class="form-group add">
            <a href="#add_presence" title="Добавить новый статус">+</a>
        </div>
        <div class="form-group add"></div>
        <div class="form-group add"></div>
        <div class="form-group add"></div>
        
        <!--<div class="form-group add">
            <a href="#add_gem" title="Добавить новую вставку">+</a>
        </div>-->
    </fieldset>
    
    <fieldset style="width: 30%; float:left; margin-left:2%;">
        
        <!--<div class="form-group">
            <select autocomplete="off" autofocus class="form-control" name="producer" placeholder="Производитель">
                
                <?php               
	                foreach ($producers as $producer)	
                    {   
                        echo("<option value='$producer'>" . $producer . "</option>");
                    }
                ?>
            </select>
        </div>
        <div class="form-group">
            <select autocomplete="off" autofocus class="form-control" name="type" placeholder="Тип изделия">
                
                <?php               
	                foreach ($types as $type)	
                    {   
                        echo("<option value='$type'>" . $type . "</option>");
                    }
                ?>
            </select>
        </div>
        <div class="form-group">
            <input autocomplete="off" autofocus class="form-control" name="articul" placeholder="Артикул" type="text"/>
        </div>
        <div class="form-group">
            <input autocomplete="off" class="form-control" name="size" placeholder="Размер" type="text"/>
        </div>
        <div class="form-group">
            <input autocomplete="off" class="form-control" name="size_common" placeholder="Размер общий" type="text"/>
        </div>
        <div class="form-group">
            <input autocomplete="off" class="form-control" name="weight" placeholder="Вес" type="text"/>
        </div>
        <div class="form-group">
            <input autocomplete="off" class="form-control" name="quantity" placeholder="Количество" type="text"/>
        </div>
        <div class="form-group">
            <select autocomplete="off" autofocus class="form-control" name="metal" placeholder="Металл">
                
                <?php               
	                foreach ($metals as $metal)	
                    {   
                        echo("<option value='$metal'>" . $metal . "</option>");
                    }
                ?>
            </select>
        </div>
        <div class="form-group">
            <select autocomplete="off" autofocus class="form-control" name="gender" placeholder="Для кого">
                
                <?php               
	                foreach ($genders as $gender)	
                    {   
                        echo("<option value='$gender'>" . $gender . "</option>");
                    }
                ?>
            </select>
        </div>
        <div class="form-group">
            <select autocomplete="off" autofocus class="form-control" name="presence" placeholder="Статус">
                
                <?php               
	                foreach ($presences as $presence)	
                    {   
                        echo("<option value='$presence'>" . $presence . "</option>");
                    }
                ?>
            </select>
        </div>
        <div class="form-group">
            <input autocomplete="off" class="form-control" name="price" placeholder="Закупочная цена" type="text"/>
        </div>
        <div class="form-group">
            <input autocomplete="off" class="form-control" name="price_sell" placeholder="Цена продажи" type="text"/>
        </div>
        <div class="form-group">
            <select autocomplete="off" autofocus class="form-control" name="user1" placeholder="Менеджер">
                
                <?php               
	                foreach ($users1 as $user1)	
                    {   
                        echo("<option value='$user1'>" . $user1 . "</option>");
                    }
                ?>
            </select>
        </div>-->
        
        <div class="form-group">
            <select autocomplete="off" autofocus class="form-control" name="gem" placeholder="Вставка">
                
                <?php               
	                foreach ($gems as $gem)	
                    {   
                        echo("<option value='$gem'>" . $gem . "</option>");
                    }
                ?>
            </select>
        </div>
        <div class="form-group">
            <input autocomplete="off" class="form-control" name="gem_quantity" placeholder="Количество вставок" type="text"/>
        </div>
        <!--<div class="form-group">
            <button class="btn btn-default" type="submit" name="create_product">
                <span aria-hidden="true" class="glyphicon "></span>
                Buy
            </button>
        </div>-->
    </fieldset>
    <fieldset style="width: 1%; float:left; margin: 0 0.5%;">
        <!--<div class="form-group add">
            <a href="#add_producer" title="Добавить нового производителя">+</a>
        </div>
        <div class="form-group add">
            <a href="#add_type" title="Добавить новый тип изделия">+</a>
        </div>
        <div class="form-group add"></div>
        <div class="form-group add"></div>
        <div class="form-group add"></div>
        <div class="form-group add"></div>
        <div class="form-group add"></div>
        <div class="form-group add">
            <a href="#add_metal" title="Добавить новый металл">+</a>
        </div>
        <div class="form-group add"></div>
        <div class="form-group add">
            <a href="#add_presence" title="Добавить новый статус">+</a>
        </div>
        <div class="form-group add"></div>
        <div class="form-group add"></div>
        <div class="form-group add"></div>-->
        
        <div class="form-group add">
            <a href="#add_gem" title="Добавить новую вставку">+</a>
        </div>
        <div class="form-group add"></div>
    </fieldset>
</form>
</div>


<a href="#x" class="overlay" id="add_producer"></a>
<div class="popup">
    <form action="edit.php" method="post">
        <h4 style= "text-align: center;">Добавить производителя</h4>
    <fieldset>
        <div class="form-group">
                <input autocomplete="off" class="form-control" name="name" placeholder="Название" type="text"/>
        </div>
        <div class="form-group">
            <button class="btn btn-default" type="submit" name="create_producer">
                <span aria-hidden="true" class="glyphicon "></span>
                Создать
            </button>
        </div>
    </fieldset>
    </form>
<a class="close" title="Закрыть" href="#close"></a>
</div>

<a href="#x" class="overlay" id="add_type"></a>
<div class="popup">
    <form  action="edit.php" method="post">
        <h4 style= "text-align: center;">Добавить тип изделия</h4>
    <fieldset>
        <div class="form-group">
                <input autocomplete="off" class="form-control" name="name" placeholder="Название" type="text"/>
        </div>
        <div class="form-group">
            <button class="btn btn-default" type="submit" name="create_type">
                <span aria-hidden="true" class="glyphicon "></span>
                Создать
            </button>
        </div>
    </fieldset>
    </form>
    <a class="close" title="Закрыть" href="#close"></a>
</div>

<a href="#x" class="overlay" id="add_metal"></a>
<div class="popup">
    <form action="edit.php" method="post">
        <h4 style= "text-align: center;">Добавить металл</h4>
    <fieldset>
        <div class="form-group">
                <input autocomplete="off" class="form-control" name="metal" placeholder="Название" type="text"/>
        </div>
        <div class="form-group">
                <input autocomplete="off" class="form-control" name="probe" placeholder="Проба" type="text"/>
        </div>
        <div class="form-group">
            <button class="btn btn-default" type="submit" name="create_metal">
                <span aria-hidden="true" class="glyphicon "></span>
                Создать
            </button>
        </div>
    </fieldset>
    </form>
    <a class="close" title="Закрыть" href="#close"></a>
</div>

<a href="#x" class="overlay" id="add_presence"></a>
<div class="popup">
    <form  action="edit.php" method="post">
        <h4 style= "text-align: center;">Добавить статус</h4>
    <fieldset>
        <div class="form-group">
                <input autocomplete="off" class="form-control" name="presence" placeholder="Статус" type="text"/>
        </div>
        <div class="form-group">
            <button class="btn btn-default" type="submit" name="create_presence">
                <span aria-hidden="true" class="glyphicon "></span>
                Создать
            </button>
        </div>
    </fieldset>
    </form>
    <a class="close" title="Закрыть" href="#close"></a>
</div>


<div id="add_gem" style="margin-left: 22%; width: 40%;">
    <form  id="for" action="edit.php" method="post" style="height:430px;">
        <h4 style= "text-align: center;">Добавить вставку</h4>
    <fieldset style="width: 93%; float:left;">
        <div class="form-group">
            <select autocomplete="off" autofocus class="form-control" name="material" placeholder="Материал">
                
                <?php               
	                foreach ($materials as $material)	
                    {   
                        echo("<option value='$material'>" . $material . "</option>");
                    }
                ?>
            </select>
        </div>
        <div class="form-group">
            <select autocomplete="off" autofocus class="form-control" name="color" placeholder="Цвет">
                
                <?php               
	                foreach ($colors as $color)	
                    {   
                        echo("<option value='$color'>" . $color . "</option>");
                    }
                ?>
            </select>
        </div>
        <div class="form-group">
            <select autocomplete="off" autofocus class="form-control" name="shape" placeholder="Форма">
                
                <?php               
	                foreach ($shapes as $shape)	
                    {   
                        echo("<option value='$shape'>" . $shape . "</option>");
                    }
                ?>
            </select>
        </div>
        <div class="form-group">
                <input autocomplete="off" class="form-control" name="gem_size" placeholder="Размер" type="text"/>
        </div>
        <div class="form-group">
            <button class="btn btn-default" type="submit" name="create_gem">
                <span aria-hidden="true" class="glyphicon "></span>
                Создать
            </button>
        </div>
    </fieldset>
    <fieldset style="width: 5%; float:right;">
        <div class="form-group add">
            <a href="#add_material" title="Добавить нового материал">+</a>
        </div>
        <div class="form-group add">
            <a href="#add_color" title="Добавить новый цвет">+</a>
        </div>
        <div class="form-group add">
            <a href="#add_shape" title="Добавить новую форму">+</a>
        </div>
    </fieldset>
    </form>
</div>
</div>

<div class="middlebar">
                
                <div id="middle"> 
<a href="#x" class="overlay" id="add_material"></a>
<div class="popup">
    <form action="edit.php" method="post">
        <h4 style= "text-align: center;">Добавить материал вставки</h4>
    <fieldset>
        <div class="form-group">
                <input autocomplete="off" class="form-control" name="name" placeholder="Название" type="text"/>
        </div>
        <div class="form-group">
            <button class="btn btn-default" type="submit" name="create_material">
                <span aria-hidden="true" class="glyphicon "></span>
                Создать
            </button>
        </div>
    </fieldset>
    </form>
    <a class="close" title="Закрыть" href="#close"></a>
</div>

<a href="#x" class="overlay" id="add_color"></a>
<div class="popup">
    <form  action="edit.php" method="post">
        <h4 style= "text-align: center;">Добавить цвет вставки</h4>
    <fieldset>
        <div class="form-group">
                <input autocomplete="off" class="form-control" name="name" placeholder="Название" type="text"/>
        </div>
        <div class="form-group">
            <button class="btn btn-default" type="submit" name="create_color">
                <span aria-hidden="true" class="glyphicon "></span>
                Создать
            </button>
        </div>
    </fieldset>
    </form>
    <a class="close" title="Закрыть" href="#close"></a>
</div>

<a href="#x" class="overlay" id="add_shape"></a>
<div class="popup">
    <form action="edit.php" method="post">
        <h4 style= "text-align: center;">Добавить форму вставки</h4>
    <fieldset>
        <div class="form-group">
                <input autocomplete="off" class="form-control" name="name" placeholder="Название" type="text"/>
        </div>
        <div class="form-group">
            <button class="btn btn-default" type="submit" name="create_shape">
                <span aria-hidden="true" class="glyphicon "></span>
                Создать
            </button>
        </div>
    </fieldset>
    </form>
    <a class="close" title="Закрыть" href="#close"></a>
</div>
</div>
<div class="sticky">
    <a href="#" data-scroll="" data-options="{speed: 1000, easing: easeOutQuad}" class="back-to-top-button"><i>UP</i></a>
</div>