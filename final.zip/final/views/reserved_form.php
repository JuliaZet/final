<script>
    function newVal(ot){

    var res = $(ot).attr('title');

    $('#sell_b').val(res);

    return false;
    }
</script>
<div class="breadcrumbs">
    <ul>
        <li><a href="index.php">Главная</a> => <a href="reserved.php">Резерв</a></li>
    </ul>
</div>
                    
<?php if (!empty($portfolio)): ?>
    <div class="container">
            <div id="top">
                <h3>Количество изделий в резерве: <?php echo count($portfolio); ?> шт.</h3>
            </div>
    </div>
            
            <div id="middle"> 

<table class="table table-striped">

    <thead>
        <tr>
            <td><strong>Фирма</strong></td>
            <td><strong>Тип</strong></td>
            <td><strong>Артикул</strong></td>
            <td><strong>Размер</strong></td>
            <td><strong>Размер изделия (мм)</strong></td>
            <td><strong>Вес (г)</strong></td>
            <td><strong>Металл</strong></td>
            <td><strong>Количество (шт.)</strong></td>
            <td><strong>Количество камней (шт.)</strong></td>
            <td><strong>Цена (грн.)</strong></td>
            <td><strong>Менеджер</strong></td>
            <td><strong>Опции</strong></td>
            <td></td>
        </tr>
    </thead>
<?php else :?>
<div class="container">
    <div id="top">
        <h3 style="margin: 150px 0;">В резерве изделий нет!</h3>
    </div>
<?php endif ?>


    <tbody>
    <?php
	    foreach ($portfolio as $row)	
        {   
            echo("<tr>");
            echo("<td>" . $row["producer"] . "</td>");
            echo("<td>" . $row["type"] . "</td>");
            echo("<td>" . $row["articul"] . "</td>");
            echo("<td>" . number_format($row["size"]) . "</td>");
            echo("<td>" . $row["size_common"] . "</td>");
            echo("<td>" . number_format($row["weight"], 2) . "</td>");
            echo("<td>" . $row["metal"] . " " . number_format($row["probe"]) . "</td>");
            echo("<td>" . number_format($row["quantity"]) . "</td>");
            echo("<td>" . number_format($row["gem_quantity"]) . "</td>");
            echo("<td>" . number_format($row["price"]) . "</td>");
            echo("<td>" . $row["user"] . "</td>");
            echo ('<td> <form name="form" method="POST" action="reserved.php">
                 <input value="'. $row['id'].'" type="hidden" name="cancel">
                 <input type="submit" class="btn btn-default"  value="Отмена">
               </form>
            </td>');
            echo('<td><a href="#sell_popup" class="btn btn-default" onclick="newVal(this)" title="'. $row['id'].'">Продать</a></td>');

            echo("</tr>");
        }

    ?>

    </tbody>

</table>

 <a href="#x" class="overlay" id="sell_popup"></a>
   <div class="popup">
     <form action="reserved.php" method="post">
    <fieldset>
        <div class="form-group">
            <input autocomplete="off" class="form-control" name="price_sell" placeholder="Цена продажи" type="text"/>
        </div>
        <div class="form-group">
            <select autocomplete="off" autofocus class="form-control" name="sell_user"  placeholder="Менеджер">
                
                <?php 

	                foreach ($users1 as $user1)	
                    {   
                        echo("<option value='$user1'>" . $user1 . "</option>");
                    }
                ?>
            </select>
        </div>
        <div class="form-group">
            <input autocomplete="off" class="form-control" name="sell_quantity" placeholder="Количество" type="text"/>
        </div>
        <div class="form-group">
            <button class="btn btn-default" type="submit" name="sell_b" id="sell_b">
                <span aria-hidden="true" class="glyphicon "></span>
                Продано
            </button>
        </div>
    </fieldset>
</form>
    <a class="close" title="Закрыть" href="#close"></a>
    </div>
<div class="container">