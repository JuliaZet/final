<div class="breadcrumbs">
    <ul>
        <li><a href="index.php">Главная</a> => <a href="sold.php">Продано</a></li>
    </ul>
</div>

                    
<?php if (!empty($portfolio)): ?>
    <div class="container">
            <div id="top">
                <h3>Продано изделий: <?php echo($q_t); ?> шт.</h3>
            </div>
    </div>

<div id="leftside">
                
<form action="sold.php" method="post" style="width:150px; padding:5px;">
    <h4 style="color: white;">Выбрать:</h4>
    <fieldset style="width:10%; float:left;">
        <div class="form-group add">
            <input type="checkbox" name="formDoor[]" value="A" title="по дате" />
        </div>
        <div class="form-group add" style="margin-top:64px;">
            <input type="checkbox" name="formDoor[]" value="B" title="по производителю" />
        </div>
        <div class="form-group add">
            <input type="checkbox" name="formDoor[]" value="C" title="по типу изделия"/>
        </div>
        <div class="form-group add">
            <input type="checkbox" name="formDoor[]" value="D" title="по менеджеру"/>
        </div>
    </fieldset>
    <fieldset style="width:80%; float:left; margin-left:5%;">
        <div class="form-group">
            <input autocomplete="off" autofocus class="form-control" name="start_date" placeholder="Нач. дата" type="date"/>
        </div>
        <div class="form-group">
            <input autocomplete="off" autofocus class="form-control" name="end_date" placeholder="Кон. дата" type="date"/>
        </div>
        <div class="form-group">
            <select autocomplete="off" autofocus class="form-control" name="producer" placeholder="Производитель">
                
                <?php               
	                foreach ($producers as $producer)	
                    {   
                        echo("<option value='$producer'>" . $producer . "</option>");
                    }
                ?>
            </select>
        </div>
        <div class="form-group">
            <select autocomplete="off" autofocus class="form-control" name="type" placeholder="Тип изделия">
                
                <?php               
	                foreach ($types as $type)	
                    {   
                        echo("<option value='$type'>" . $type . "</option>");
                    }
                ?>
            </select>
        </div>
        <div class="form-group">
            <select autocomplete="off" autofocus class="form-control" name="manager" placeholder="Менеджер">
                
                <?php               
	                foreach ($managers as $manager)	
                    {   
                        echo("<option value='$manager'>" . $manager . "</option>");
                    }
                ?>
            </select>
        </div>
        <div class="form-group" style="margin-bottom:15px;">
            <button class="btn btn-default" type="submit" name="search">
                <span aria-hidden="true" class="glyphicon "></span>
                Выбрать
            </button>
        </div>
    </fieldset>
</form>
</div>
            
<div class="middlebar">
            
            <div id="middle"> 

<table class="table table-striped">

    <thead>
        <tr>
            <td><strong>Производитель</strong></td>
            <td><strong>Тип</strong></td>
            <td><strong>Артикул</strong></td>
            <td><strong>Размер</strong></td>
            <!--<td><strong>Размер изделия (мм)</strong></td>-->
            <td><strong>Вес (г)</strong></td>
            <td><strong>Металл</strong></td>
            <td><strong>Количество (шт.)</strong></td>
            <!--<td><strong>Количество камней (шт.)</strong></td>-->
            <td><strong>Цена (грн.)</strong></td>
            <td><strong>Цена продажи (грн.)</strong></td>
            <td><strong>Менеджер</strong></td>
            <td><strong>Дата</strong></td>
            <td><strong>Профит</strong></td>
            <td><strong>
                <form name="form" method="POST" action="sold.php">
                 <input value="'. $row['id'].'" type="hidden" name="ex">
                 <input type="submit" class="btn btn-default" onclick="self.location.href = '/php/dataexport/1/';" value="Экспорт в .xls">
               </form>
            </strong></td>

        </tr>
    </thead>
<?php else :?>
<div class="container">
    <div id="top">
        <h3 style="margin: 150px 0;">Ничего не продано!</h3>
    </div>
<?php endif ?>


    <tbody>
    <?php
	    foreach ($portfolio as $row)	
        {   
            echo("<tr>");
            echo("<td>" . $row["producer"] . "</td>");
            echo("<td>" . $row["type"] . "</td>");
            echo("<td>" . $row["articul"] . "</td>");
            echo("<td>" . number_format($row["size"]) . "</td>");
            //echo("<td>" . $row["size_common"] . "</td>");
            echo("<td>" . number_format($row["weight"], 2) . "</td>");
            echo("<td>" . $row["metal"] . " " . number_format($row["probe"]) . "</td>");
            echo("<td>" . number_format($row["quantity_s"]) . "</td>");
            //echo("<td>" . number_format($row["gem_quantity"]) . "</td>");
            echo("<td>" . number_format($row["price"]) . "</td>");
            echo("<td>" . number_format($row["price_s"]) . "</td>");
            echo("<td>" . $row["user"] . "</td>");
            echo("<td>" . date('Y-m-d', strtotime($row["data"])) . "</td>");
            //echo ('<td> <form name="form" method="POST" action="sold.php">
            //     <input value="'. $row['id'].'" type="hidden" name="cancel">
            //     <input type="submit" class="btn btn-default" value="Отмена">
            //   </form>
            //</td>');
            //echo ('<td> <form name="form" method="POST" action="sold.php">
            //     <input value="'. $row['id'].'" type="hidden" name="reserve">
            //     <input type="submit" class="btn btn-default" value="В резерв">
            //   </form>
            //</td>');
            echo("<td>" . number_format($row["price_s"]*$row["quantity_s"] - $row["price"]*$row["quantity_s"]) . "</td>");
            echo("<td></td>");

            echo("</tr>");
        }

    ?>
    <tr>
        <td><strong>Всего:</strong></td>
        <td></td><td></td><td></td><td></td><td></td>
        <td><strong><?=number_format($q_t)?></strong></td>
        <td><strong><?=number_format($p_t)?></strong></td>
        <td><strong><?=number_format($ps_t)?></strong></td>
        <td></td><td></td>
        <td><strong><?=number_format($profit)?></strong></td>
        <td></td>
    </tr>

    </tbody>

</table>


<div class="container">