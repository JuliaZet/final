<div class="breadcrumbs">
    <ul>
        <li><a href="index.php">Главная</a> => <a href="managers.php">Менеджеры</a></li>
    </ul>
</div>
            
                <?php if (!empty($_SESSION["id"])): ?>
                    <h3>Всего менеджеров: <?php echo count($products_per_user); ?></h3>
                <?php endif ?>
            
            <div id="leftside">
                
                <?php if (!empty($_SESSION["id"])): ?>
                    <ul class="nav">
                        <li><a href="register.php">Зарегистрировать нового менеджера</a></li>
                        <li><a href="del_user.php">Удалить менеджера</a></li>
                    </ul>
                <?php endif ?>
            </div>
            
<div class="mainbar">

            <div id="top">
                
                <?php if (!empty($_SESSION["id"])): ?>
                    <h4>Продано: <?=number_format($All)?> шт.</h4>
                <?php endif ?>
            </div>

            
            <div id="middle">            
            
        
<table class="table table-striped">

    <thead>
        <tr>
            <td><strong>Менеджер</strong></td>
            <td><strong>Кольца (шт.)</strong></td>
            <td><strong>Серьги (шт.)</strong></td>
            <td><strong>Подвесы (шт.)</strong></td>
            <td><strong>Цепочки (шт.)</strong></td>
            <td><strong>Вcего (шт.)</strong></td>
        </tr>
    </thead>

    <tbody>
    <?php
	    foreach ($products_per_user as $row)	
        {   
            echo("<tr>");
            echo("<td>" . $row["user"] . "</td>");
            echo("<td>" . number_format($row["QRing"]) . "</td>");
            echo("<td>" . number_format($row["QEarrings"]) . "</td>");
            echo("<td>" . number_format($row["QPendant"]) . "</td>");
            echo("<td>" . number_format($row["QChain"]) . "</td>");
            echo("<td><strong>" . number_format($row["total"]) . "</strong></td>");
            echo("</tr>");
        }
    ?>

     <tr>
        <td><strong>ВСЕГО</strong></td>
        <td><strong><?=number_format($All_ring)?></strong></td>
        <td><strong><?=number_format($All_earrings)?></strong></td>
        <td><strong><?=number_format($All_pendant)?></strong></td>
        <td><strong><?=number_format($All_chanes)?></strong></td>
        <td><strong><?=number_format($All)?></strong></td>
    </tr>

    </tbody>

</table>

<div id="top">
                
                <?php if (!empty($_SESSION["id"])): ?>
                    <h4>В наличии: <?=number_format($All1)?> шт.</h4>
                <?php endif ?>
            </div>

            
            <div id="middle">            
            
        
<table class="table table-striped">

    <thead>
        <tr>
            <td><strong>Менеджер</strong></td>
            <td><strong>Кольца (шт.)</strong></td>
            <td><strong>Серьги (шт.)</strong></td>
            <td><strong>Подвесы (шт.)</strong></td>
            <td><strong>Цепочки (шт.)</strong></td>
            <td><strong>Вcего (шт.)</strong></td>
        </tr>
    </thead>

    <tbody>
    <?php
	    foreach ($products_per_user1 as $row)	
        {   
            echo("<tr>");
            echo("<td>" . $row["user"] . "</td>");
            echo("<td>" . number_format($row["QRing"]) . "</td>");
            echo("<td>" . number_format($row["QEarrings"]) . "</td>");
            echo("<td>" . number_format($row["QPendant"]) . "</td>");
            echo("<td>" . number_format($row["QChain"]) . "</td>");
            echo("<td><strong>" . number_format($row["total"]) . "</strong></td>");
            echo("</tr>");
        }
    ?>

     <tr>
        <td><strong>ВСЕГО</strong></td>
        <td><strong><?=number_format($All_ring1)?></strong></td>
        <td><strong><?=number_format($All_earrings1)?></strong></td>
        <td><strong><?=number_format($All_pendant1)?></strong></td>
        <td><strong><?=number_format($All_chanes1)?></strong></td>
        <td><strong><?=number_format($All1)?></strong></td>
    </tr>

    </tbody>

</table>

<div id="top">
                
                <?php if (!empty($_SESSION["id"])): ?>
                    <h4>В резерве: <?=number_format($All2)?> шт.</h4>
                <?php endif ?>
            </div>

            
            <div id="middle">            
            
        
<table class="table table-striped">

    <thead>
        <tr>
            <td><strong>Менеджер</strong></td>
            <td><strong>Кольца (шт.)</strong></td>
            <td><strong>Серьги (шт.)</strong></td>
            <td><strong>Подвесы (шт.)</strong></td>
            <td><strong>Цепочки (шт.)</strong></td>
            <td><strong>Вcего (шт.)</strong></td>
        </tr>
    </thead>

    <tbody>
    <?php
	    foreach ($products_per_user2 as $row)	
        {   
            echo("<tr>");
            echo("<td>" . $row["user"] . "</td>");
            echo("<td>" . number_format($row["QRing"]) . "</td>");
            echo("<td>" . number_format($row["QEarrings"]) . "</td>");
            echo("<td>" . number_format($row["QPendant"]) . "</td>");
            echo("<td>" . number_format($row["QChain"]) . "</td>");
            echo("<td><strong>" . number_format($row["total"]) . "</strong></td>");
            echo("</tr>");
        }
    ?>

     <tr>
        <td><strong>ВСЕГО</strong></td>
        <td><strong><?=number_format($All_ring2)?></strong></td>
        <td><strong><?=number_format($All_earrings2)?></strong></td>
        <td><strong><?=number_format($All_pendant2)?></strong></td>
        <td><strong><?=number_format($All_chanes2)?></strong></td>
        <td><strong><?=number_format($All2)?></strong></td>
    </tr>

    </tbody>

</table>
<div class="container">