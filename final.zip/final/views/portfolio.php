<script>
    function newVal(ot){

    var res = $(ot).attr('title');

    $('#m_theme').val(res);

    return false;
    }
    function newVal1(ot){

    var res = $(ot).attr('title');

    $('#sell_b').val(res);

    return false;
    }

</script>

<div class="breadcrumbs">
    <ul>
        <li><a href="index.php">Главная</a></li>
    </ul>
</div>   

                <?php if (!empty($portfolio)): ?>
    <div class="container">
            <div id="top">
                    <h3>Всего найдено позиций: <?php echo count($portfolio); ?> шт.</h3>
            </div>
    </div>
   
<div id="leftside">
                
<form action="index.php" method="post" style="width:150px; padding:5px;">
    <h4 style="color: white;">Поиск:</h4>
    <fieldset style="width:10%; float:left;">
        <div class="form-group add">
            <input type="checkbox" name="formDoor[]" value="A" title="по артикулу" />
        </div>
        <div class="form-group add">
            <input type="checkbox" name="formDoor[]" value="B" title="по производителю" />
        </div>
        <div class="form-group add">
            <input type="checkbox" name="formDoor[]" value="C" title="по типу изделия"/>
        </div>
        <div class="form-group add">
            <input type="checkbox" name="formDoor[]" value="D" title="по размеру"/>
        </div>
        <div class="form-group add">
            <input type="checkbox" name="formDoor[]" value="E" title="по статусу"/>
        </div>
        <div class="form-group add">
            <input type="checkbox" name="formDoor[]" value="F" title="по менеджеру"/>
        </div>
    </fieldset>
    <fieldset style="width:80%; float:left; margin-left:5%;">
        <div class="form-group">
            <input autocomplete="off" autofocus class="form-control" name="articul" placeholder="Артикул" type="text"/>
        </div>
        <div class="form-group">
            <select autocomplete="off" autofocus class="form-control" name="producer" placeholder="Производитель">
                
                <?php               
	                foreach ($producers as $producer)	
                    {   
                        echo("<option value='$producer'>" . $producer . "</option>");
                    }
                ?>
            </select>
        </div>
        <div class="form-group">
            <select autocomplete="off" autofocus class="form-control" name="type" placeholder="Тип изделия">
                
                <?php               
	                foreach ($types as $type)	
                    {   
                        echo("<option value='$type'>" . $type . "</option>");
                    }
                ?>
            </select>
        </div>
        <div class="form-group">
            <input autocomplete="off" class="form-control" name="size" placeholder="Размер" type="text"/>
        </div>
        <div class="form-group">
            <select autocomplete="off" autofocus class="form-control" name="presence" placeholder="Статус">
                
                <?php               
	                foreach ($presences as $presence)	
                    {   
                        echo("<option value='$presence'>" . $presence . "</option>");
                    }
                ?>
            </select>
        </div>
        <div class="form-group">
            <select autocomplete="off" autofocus class="form-control" name="manager"  placeholder="Менеджер">
                
                <?php 

	                foreach ($users1 as $user1)	
                    {   
                        echo("<option value='$user1'>" . $user1 . "</option>");
                    }
                ?>
            </select>
        </div>
        <div class="form-group" style="margin-bottom:15px;">
            <button class="btn btn-default" type="submit" name="search">
                <span aria-hidden="true" class="glyphicon "></span>
                Найти
            </button>
        </div>
    </fieldset>
</form>
</div>
            
<div class="middlebar">



            
            <div id="middle">  
<table class="table table-striped">

    <thead>
        <tr>
            <td><strong>Производитель</strong></td>
            <td><strong>Тип</strong></td>
            <td><strong>Артикул</strong></td>
            <td><strong>Размер</strong></td>
            <!--<td><strong>Размер изделия (мм)</strong></td>-->
            <td><strong>Вес (г)</strong></td>
            <td><strong>Металл</strong></td>
            <td><strong>Количество (шт.)</strong></td>
            <!--<td><strong>Количество камней (шт.)</strong></td>-->
            <td><strong>Цена (грн.)</strong></td>
            <td><strong>Менеджер</strong></td>
            <td><strong>Статус</strong></td>
            <td><strong>Опции</strong></td>
            
        </tr>
    </thead>

<?php else :?>
<div class="container">
    <div id="top">
        <h3 style="margin: 150px 0;">Ничего не найдено!</h3>
    </div>
<?php endif ?>

    <tbody>
    <?php
	    foreach ($portfolio as $row)	
        {   
            echo("<tr>");
            echo("<td>" . $row["producer"] . "</td>");
            echo("<td>" . $row["type"] . "</td>");
            echo("<td>" . $row["articul"] . "</td>");
            echo("<td>" . number_format($row["size"]) . "</td>");
           // echo("<td>" . $row["size_common"] . "</td>");
            echo("<td>" . number_format($row["weight"], 2) . "</td>");
            echo("<td>" . $row["metal"] . " " . number_format($row["probe"]) . "</td>");
            echo("<td>" . number_format($row["quantity"]) . "</td>");
            //echo("<td>" . number_format($row["gem_quantity"]) . "</td>");
            echo("<td>" . number_format($row["price"]) . "</td>");
            echo("<td>" . $row["user"] . "</td>");
            echo('<td><a href="#status" onclick="newVal(this)" title="'. $row['id'].'">' . $row["presence"] . '</a></td>');
            //echo ('<td> <form name="form" method="POST" action="index.php">
            //     <input value="'. $row['id'].'" type="hidden" name="reserve">
            //     <input type="submit" class="btn btn-default"  value="В резерв">
            //   </form>
            //</td>');
            
            echo('<td><a href="#sell_popup" class="btn btn-default" onclick="newVal1(this)" title="'. $row['id'].'">Продать</a></td>');
 
   //         echo ('<td> <form name="form" method="POST" action="index.php">
     //            <input value="'. $row['id'].'" type="hidden" name="sold">
       //          <input type="submit" class="btn btn-default" value="Продать">
         //      </form>
           // </td>');
            echo("</tr>");
        }
    ?>

    </tbody>

</table>

 <a href="#x" class="overlay" id="status"></a>
   <div class="popup">
     <form action="index.php" method="post">
    <fieldset>
        <div class="form-group">
            <select autocomplete="off" autofocus class="form-control" name="status"  placeholder="Статус">
                
                <?php 

	                foreach ($presences as $presence)	
                    {   
                        echo("<option value='$presence'>" . $presence . "</option>");
                    }
                ?>
            </select>
        </div>
        <div class="form-group">
            <input autocomplete="off" class="form-control" name="new_quantity" placeholder="Количество" type="text"/>
        </div>
        <div class="form-group">
            <button class="btn btn-default" type="submit" name="m_theme" id="m_theme">
                <span aria-hidden="true" class="glyphicon "></span>
                Изменить
            </button>
        </div>
    </fieldset>
</form>
    <a class="close" title="Закрыть" href="#close"></a>
    </div>
    
    <a href="#x" class="overlay" id="sell_popup"></a>
   <div class="popup">
     <form action="index.php" method="post">
    <fieldset>
        <div class="form-group">
            <input autocomplete="off" class="form-control" name="price_sell" placeholder="Цена продажи" type="text"/>
        </div>
        <div class="form-group">
            <select autocomplete="off" autofocus class="form-control" name="sell_user"  placeholder="Менеджер">
                
                <?php 

	                foreach ($users1 as $user1)	
                    {   
                        echo("<option value='$user1'>" . $user1 . "</option>");
                    }
                ?>
            </select>
        </div>
        <div class="form-group">
            <input autocomplete="off" class="form-control" name="sell_quantity" placeholder="Количество" type="text"/>
        </div>
        <div class="form-group">
            <button class="btn btn-default" type="submit" name="sell_b" id="sell_b">
                <span aria-hidden="true" class="glyphicon "></span>
                Продано
            </button>
        </div>
    </fieldset>
</form>
    <a class="close" title="Закрыть" href="#close"></a>
    </div>