<div class="container">

            <div id="top">
                
            </div>

            
            <div id="middle">  
            
            
            
<form id="for" action="login.php" method="post">
    <fieldset>
        <div class="form-group">
            <input autocomplete="off" autofocus class="form-control" name="username" placeholder="Логин" type="text"/>
        </div>
        <div class="form-group">
            <input class="form-control" name="password" placeholder="Пароль" type="password"/>
        </div>
        <div class="form-group">
            <button class="btn btn-default" type="submit">
                <span aria-hidden="true" class="glyphicon glyphicon-log-in"></span>
                Войти
            </button>
        </div>
    </fieldset>
</form>
